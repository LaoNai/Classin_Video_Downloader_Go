* []  investigate - should empty IPv6 be legit (and other nitpicks)? https://url.spec.whatwg.org/#host-parsing
* []  investigate - nice? uses whatwg errors terminology
* [x] injects fixes in main (last rune vs once)
* []  doc: complete the librarian/archivist work on specs, etc + FAQ to clarify the somewhat arcane world of this set of RFCs.

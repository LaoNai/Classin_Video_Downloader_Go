# font

font is a library that handles loading and utilizing Opentype fonts.

`font/opentype` implements the low level parsing of a font file and its tables,
and `font` provides an higher level API usable by shapers and renderers.

// Package plural provides support for pluralizing messages
// according to CLDR rules http://cldr.unicode.org/index/cldr-spec/plural-rules
package plural

// Packge convert contains functions for converting to dbus data structures.
package convert

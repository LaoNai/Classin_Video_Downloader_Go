// Package appearance is a helper package for reading appearance settings.
package appearance

// Namespace defines the namespace of the appearance portal.
const Namespace = "org.freedesktop.appearance"
